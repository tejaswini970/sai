
package com.test.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {
	//@RequestMapping("/show")
	public String showHomePage()
	{
		return("index");
	}
	
	@RequestMapping("/hello")
	public ModelAndView sayHello(@RequestParam("msg") String msg) {
		
		String str=msg;
		ModelAndView model=new ModelAndView("success","message",str);
		return(model);
		
	}
	
	@RequestMapping(value="/hello1",method=RequestMethod.POST)
	public String sayHello1(Model model)
	{
		model.addAttribute("message", "Hello from HELLO1");
		return("success");
	}

}
