package com.ars.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ars.bean.BookingInformationBean;
import com.ars.bean.FlightInformationBean;
import com.ars.dao.IArsDao;
import com.ars.exception.ARSException;

@Service
public class ArsServiceImpl implements IArsService {

	/**
	 * 
	 */

	@Autowired
	private IArsDao arsDao;

	public IArsDao getArsDao() {
		return arsDao;
	}

	public void setArsDao(IArsDao arsDao) {
		this.arsDao = arsDao;
	}

	/**
	 * confirmBooking()
	 *
	 */

	@Override
	public BookingInformationBean confirmBooking(
			BookingInformationBean bookingInformationBean) throws ARSException {
		return arsDao.confirmBooking(bookingInformationBean);
	}

	/**
	 * displayBooking()
	 *
	 */

	@Override
	public BookingInformationBean displayBooking(String bookingId)
			throws ARSException {

		return arsDao.displayBooking(bookingId);
	}

	/**
	 * cancelBooking()
	 *
	 */

	@Override
	public BookingInformationBean cancelBooking(String bookingId)
			throws ARSException {

		return arsDao.cancelBooking(bookingId);
	}

	/**
	 * updateBooking()
	 *
	 */

	@Override
	public BookingInformationBean updateBooking(String bookingId,
			String cust_email) throws ARSException {

		return arsDao.updateBooking(bookingId, cust_email);
	}

	/**
	 * viewFlights()
	 *
	 */

	@Override
	public List<FlightInformationBean> viewFlights(String Source,
			String destination) throws ARSException {

		return arsDao.viewFlights(Source, destination);
	}

	/**
	 * viewFlight()
	 *
	 */

	@Override
	public FlightInformationBean viewFlight(String flightNumber)
			throws ARSException {

		return arsDao.viewFlight(flightNumber);
	}

}
